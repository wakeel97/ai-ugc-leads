import { DorkQueryItem } from '../types/scraper';

export const DORK_TEMPLATES: DorkQueryItem[] = [
  {
    id: 'shopify-add-to-cart',
    title: 'Shopify Storefronts by Product Keyword',
    dork: 'site:myshopify.com "add to cart" "{niche}"',
    platform: 'Shopify',
    purpose: 'Directly finds registered myshopify subdomains selling your niche product with active cart setups.'
  },
  {
    id: 'shopify-collections',
    title: 'Collection Catalog Footprint',
    dork: 'inurl:collections/all "shipping policy" "{niche}" -site:amazon.com',
    platform: 'Shopify',
    purpose: 'Targets standard Shopify collection catalog pages with checkout & shipping policy pages.'
  },
  {
    id: 'powered-by-shopify',
    title: 'Footer Signature & Contact Page',
    dork: '"powered by shopify" "{niche}" "contact us" -site:shopify.com',
    platform: 'Shopify',
    purpose: 'Locates brands retaining the default Shopify footer watermark with explicit contact details.'
  },
  {
    id: 'tiktok-pixel-ads',
    title: 'Brands Actively Using TikTok Marketing',
    dork: '"add to cart" "track your order" "{niche}" "tiktok"',
    platform: 'TikTok Shop',
    purpose: 'Finds DTC brands running TikTok campaigns or embedding TikTok social feeds on storefront.'
  },
  {
    id: 'review-apps-loox',
    title: 'Stores with UGC Photo/Video Review Apps',
    dork: 'inurl:products "{niche}" "loox-rating" OR "judgeme" OR "okendo"',
    platform: 'Shopify',
    purpose: 'Finds stores already primed for social proof that have existing customer photo/video reviews.'
  },
  {
    id: 'replo-landing-pages',
    title: 'High-Growth DTC Media Buyers (Replo/Shogun)',
    dork: 'inurl:pages "free shipping" "{niche}" "replo" OR "shogun"',
    platform: 'Universal DTC',
    purpose: 'Identifies brands creating dedicated custom advertorials/landing pages for paid Meta/TikTok ad traffic.'
  },
  {
    id: 'tiktok-shop-storefront',
    title: 'TikTok Shop & Creator Collab Brands',
    dork: '"{niche}" "tiktok shop" "join our creator program" OR "collab"',
    platform: 'TikTok Shop',
    purpose: 'Uncovers brands actively seeking UGC creators and offering affiliate commissions.'
  }
];

export interface NicheDefinition {
  id: string;
  label: string;
  category: string;
  desc: string;
  defaultKeyword: string;
  aiUgcHook: string;
}

// 30 High-Growth E-commerce & DTC Niches with massive Meta/TikTok ad spend & AI UGC demand
export const NICHES: NicheDefinition[] = [
  // 1-5: Beauty, Personal Care & Grooming
  { 
    id: 'skincare', 
    label: 'Skincare & Cosmetics', 
    category: 'Beauty & Personal Care',
    desc: 'Serums, LED face masks, cleansers, SPF sunscreens', 
    defaultKeyword: 'skincare serum',
    aiUgcHook: 'Before-and-after texture comparison & 14-day glass skin routine'
  },
  { 
    id: 'haircare', 
    label: 'Hair Growth & Scalp Care', 
    category: 'Beauty & Personal Care',
    desc: 'Rosemary hair oils, derma rollers, scalp detox scrubs', 
    defaultKeyword: 'hair growth oil',
    aiUgcHook: 'Microscope scalp zoom before/after & shedding reduction testimonial'
  },
  { 
    id: 'oralcare', 
    label: 'Teeth Whitening & Oral Care', 
    category: 'Beauty & Personal Care',
    desc: 'Purple color-correcting serum, water flossers, PAP whitening', 
    defaultKeyword: 'teeth whitening serum',
    aiUgcHook: 'Instant mirror reveal & yellow stain wipe-away reaction'
  },
  { 
    id: 'mens-grooming', 
    label: 'Men’s Grooming & Beard Care', 
    category: 'Beauty & Personal Care',
    desc: 'Ball trimmers, beard growth kits, solid colognes, safety razors', 
    defaultKeyword: 'beard growth oil',
    aiUgcHook: 'Girlfriend reaction hook & no-nick irritation shower test'
  },
  { 
    id: 'fragrance', 
    label: 'Clean Fragrances & Dupe Scents', 
    category: 'Beauty & Personal Care',
    desc: 'Pheromone perfumes, luxury dupe oils, long-lasting solids', 
    defaultKeyword: 'pheromone perfume',
    aiUgcHook: 'Stranger compliment blind test & 12-hour wrist wear test'
  },

  // 6-10: Health, Wellness & Nutrition
  { 
    id: 'supplements', 
    label: 'Nutritional Supplements', 
    category: 'Health & Wellness',
    desc: 'Nootropics, creatine gummies, collagen, sea moss gel', 
    defaultKeyword: 'creatine gummies',
    aiUgcHook: 'Morning brain-fog lift & taste test vs chalky powders'
  },
  { 
    id: 'mushroom-coffee', 
    label: 'Functional Mushroom Coffee', 
    category: 'Health & Wellness',
    desc: 'Lion’s mane coffee, adaptogen blends, cordyceps elixir', 
    defaultKeyword: 'mushroom coffee',
    aiUgcHook: 'Replacing afternoon espresso crash & afternoon jitters fix'
  },
  { 
    id: 'greens-powders', 
    label: 'Daily Super Greens Powders', 
    category: 'Health & Wellness',
    desc: 'Debloat greens, digestive enzymes, prebiotic powders', 
    defaultKeyword: 'daily greens powder',
    aiUgcHook: 'Flat stomach morning debloat routine & water shaker taste test'
  },
  { 
    id: 'electrolytes', 
    label: 'Hydration & Electrolyte Mixes', 
    category: 'Health & Wellness',
    desc: 'Zero-sugar hydration sticks, post-workout mineral salt', 
    defaultKeyword: 'electrolyte powder',
    aiUgcHook: 'Hangover rescue & 3 PM slump brain fog clarity test'
  },
  { 
    id: 'sleep-wellness', 
    label: 'Sleep Optimization & Mouth Tape', 
    category: 'Health & Wellness',
    desc: 'Mouth tape, magnesium sleep gummies, circadian sunrise alarms', 
    defaultKeyword: 'mouth tape for sleeping',
    aiUgcHook: 'Oura/Apple Watch deep sleep score surge & nasal breathing demo'
  },

  // 11-15: Fitness, Athleisure & Active Lifestyle
  { 
    id: 'fitness-gear', 
    label: 'Home Gym & Recovery Gear', 
    category: 'Fitness & Athletics',
    desc: 'Weighted jump ropes, massage guns, grip strengtheners', 
    defaultKeyword: 'weighted jump rope',
    aiUgcHook: '10-minute intense calorie burn & sore muscle recovery demo'
  },
  { 
    id: 'athleisure', 
    label: 'Athleisure & Gym Activewear', 
    category: 'Fitness & Athletics',
    desc: 'Squat-proof leggings, pump covers, seamless gym sets', 
    defaultKeyword: 'gym leggings seamless',
    aiUgcHook: 'Gym lighting squat test & high-waist tummy control try-on'
  },
  { 
    id: 'shapewear', 
    label: 'Sculpting Shapewear & Bodysuits', 
    category: 'Fitness & Athletics',
    desc: 'Snatching bodysuits, backless waist cinchers, butt lifters', 
    defaultKeyword: 'sculpting bodysuit',
    aiUgcHook: 'Dress zip-up instant waist-cinching dramatic transformation'
  },
  { 
    id: 'barefoot-shoes', 
    label: 'Barefoot & Minimalist Footwear', 
    category: 'Fitness & Athletics',
    desc: 'Zero-drop trail shoes, wide toe-box sneakers, recovery slides', 
    defaultKeyword: 'barefoot shoes wide toe',
    aiUgcHook: 'Narrow sneaker toe squish vs natural splay foot relief'
  },
  { 
    id: 'posture-correctors', 
    label: 'Posture & Ergonomic Braces', 
    category: 'Fitness & Athletics',
    desc: 'Upper back posture trainers, neck traction pillows, lumbar belts', 
    defaultKeyword: 'posture corrector brace',
    aiUgcHook: 'Desk hunchback slouching vs instant posture alignment'
  },

  // 16-20: Consumer Tech, Gadgets & Everyday Carry (EDC)
  { 
    id: 'gadgets', 
    label: 'Everyday Tech & Mobile Gadgets', 
    category: 'Tech & Gadgets',
    desc: 'MagSafe powerbanks, phone gimbals, 3-in-1 folding chargers', 
    defaultKeyword: 'magsafe power bank',
    aiUgcHook: 'Airport battery panic rescue & minimalist cable-free travel'
  },
  { 
    id: 'smart-rings', 
    label: 'Smart Rings & Health Wearables', 
    category: 'Tech & Gadgets',
    desc: 'Titanium smart health rings, biometric sleep trackers', 
    defaultKeyword: 'smart ring health',
    aiUgcHook: 'Ditching bulky smartwatches for aesthetic titanium sleep ring'
  },
  { 
    id: 'audio-earbuds', 
    label: 'Sleep Earbuds & Audio Gear', 
    category: 'Tech & Gadgets',
    desc: 'Ultra-thin side-sleeper earbuds, bone conduction headsets', 
    defaultKeyword: 'sleep earbuds noise masking',
    aiUgcHook: 'Snoring partner noise blocking & side sleeper pillow comfort'
  },
  { 
    id: 'minimalist-wallets', 
    label: 'Minimalist Wallets & EDC', 
    category: 'Tech & Gadgets',
    desc: 'Slim RFID aluminum cardholders, key organizers, coin trays', 
    defaultKeyword: 'minimalist rfid wallet',
    aiUgcHook: 'Throwing away bulky leather dad-wallet pocket dump'
  },
  { 
    id: 'car-accessories', 
    label: 'Auto Gadgets & Car Detailing', 
    category: 'Tech & Gadgets',
    desc: 'Ceramic paint sealants, cordless tire inflators, cup-holder trays', 
    defaultKeyword: 'ceramic car coating spray',
    aiUgcHook: 'Satisfying car wash water beading & emergency highway tire fix'
  },

  // 21-25: Pet Care & Pet Wellness
  { 
    id: 'pet-supplements', 
    label: 'Pet Allergy & Joint Chews', 
    category: 'Pet Care',
    desc: 'Dog allergy soft chews, hip & joint glucosamine, gut probiotics', 
    defaultKeyword: 'dog allergy chews',
    aiUgcHook: 'Relief for paw licking & scratching dog parent emotional story'
  },
  { 
    id: 'pet-accessories', 
    label: 'Smart Pet Gadgets & Grooming', 
    category: 'Pet Care',
    desc: 'Self-cleaning litter boxes, anti-bark ultrasonic collars, fur vacuums', 
    defaultKeyword: 'pet grooming vacuum',
    aiUgcHook: 'Satisfying golden retriever shedding vacuum couch test'
  },
  { 
    id: 'fresh-pet-food', 
    label: 'Human-Grade Fresh Dog Food', 
    category: 'Pet Care',
    desc: 'Raw freeze-dried dog food, gently cooked meal subscriptions', 
    defaultKeyword: 'freeze dried dog food',
    aiUgcHook: 'Dry brown kibble autopsy vs real beef bowl reaction'
  },

  // 26-30: Home, Kitchen, Fashion & Specialty Food
  { 
    id: 'cookware', 
    label: 'Non-Toxic Ceramic Cookware', 
    category: 'Home & Kitchen',
    desc: 'PTFE-free frying pans, aesthetic Dutch ovens, silicone utensils', 
    defaultKeyword: 'non toxic ceramic cookware',
    aiUgcHook: 'Teflon toxin warning & cheese sliding off pan with 0 butter'
  },
  { 
    id: 'coffee-gear', 
    label: 'Specialty Coffee Gear & Espresso', 
    category: 'Home & Kitchen',
    desc: 'Electric burr grinders, portable espresso makers, cold brew jugs', 
    defaultKeyword: 'portable espresso maker',
    aiUgcHook: 'Saving $7/day on Starbucks with 60-second home espresso pull'
  },
  { 
    id: 'desk-setup', 
    label: 'Desk Setup & Workspace Ergonomics', 
    category: 'Home & Kitchen',
    desc: 'Screenbar monitor lights, wool felt desk pads, cable management trays', 
    defaultKeyword: 'screenbar monitor light',
    aiUgcHook: 'Night desk aesthetic transformation & eye-strain screen glare fix'
  },
  { 
    id: 'waterproof-jewelry', 
    label: 'Waterproof & Tarnish-Free Jewelry', 
    category: 'Fashion & Accessories',
    desc: '18k PVD gold plated chains, sweat-proof rings, huggie earrings', 
    defaultKeyword: 'waterproof gold jewelry',
    aiUgcHook: 'Gym, shower, & perfume chlorine wear test with no green skin'
  },
  { 
    id: 'travel-gear', 
    label: 'Travel Bags & Packing Cubes', 
    category: 'Fashion & Accessories',
    desc: 'Compression packing cubes, personal item backpacks, sling bags', 
    defaultKeyword: 'compression packing cubes',
    aiUgcHook: 'Packing 14 days of clothes into personal item budget airline bag'
  },
  { 
    id: 'blue-light-glasses', 
    label: 'Blue-Light & Computer Eyewear', 
    category: 'Fashion & Accessories',
    desc: 'Screen protection glasses, stylish anti-glare specs, clip-ons', 
    defaultKeyword: 'blue light blocking glasses',
    aiUgcHook: 'Screen glare blue laser pen test & end-of-day headache relief'
  },
  { 
    id: 'healthy-snacks', 
    label: 'High-Protein Snacks & Keto Treats', 
    category: 'Food & Beverage',
    desc: 'Keto cereal, high-protein puffs, grass-fed biltong beef sticks', 
    defaultKeyword: 'high protein keto cereal',
    aiUgcHook: 'Curbing late-night sweet tooth with 1g sugar & 15g protein'
  }
];
