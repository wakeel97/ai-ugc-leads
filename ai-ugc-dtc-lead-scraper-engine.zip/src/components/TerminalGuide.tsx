import React, { useState } from 'react';
import { Terminal, Copy, Check, Info, ShieldAlert, Zap, BookOpen } from 'lucide-react';

export const TerminalGuide: React.FC = () => {
  const [activeOs, setActiveOs] = useState<'mac' | 'windows'>('mac');
  const [copiedStep, setCopiedStep] = useState<number | null>(null);

  const copyCommand = (cmd: string, stepIndex: number) => {
    navigator.clipboard.writeText(cmd);
    setCopiedStep(stepIndex);
    setTimeout(() => setCopiedStep(null), 2000);
  };

  const macSteps = [
    {
      title: '1. Create & Activate Virtual Environment',
      desc: 'Isolates Python dependencies to keep your system clean.',
      cmd: 'python3 -m venv venv && source venv/bin/activate'
    },
    {
      title: '2. Install Free Requirements',
      desc: 'Installs requests, beautifulsoup4, and playwright with zero paid keys.',
      cmd: 'pip install requests beautifulsoup4 playwright'
    },
    {
      title: '3. (Optional) Install Playwright Chromium Browser',
      desc: 'Only needed if you want full headless JavaScript rendering for complex storefronts.',
      cmd: 'playwright install chromium'
    },
    {
      title: '4. Run the UGC DTC Lead Scraper',
      desc: 'Starts discovering brands, qualifying their storefronts, and exporting to leads.csv.',
      cmd: 'python ugc_lead_scraper.py --niche skincare --limit 20 --output skincare_leads.csv'
    }
  ];

  const winSteps = [
    {
      title: '1. Create & Activate Virtual Environment (PowerShell)',
      desc: 'Isolates Python dependencies on Windows.',
      cmd: 'python -m venv venv; .\\venv\\Scripts\\Activate.ps1'
    },
    {
      title: '2. Install Free Requirements',
      desc: 'Installs requests, beautifulsoup4, and playwright.',
      cmd: 'pip install requests beautifulsoup4 playwright'
    },
    {
      title: '3. (Optional) Install Playwright Chromium Browser',
      desc: 'Required if running with --playwright flag on Windows.',
      cmd: 'playwright install chromium'
    },
    {
      title: '4. Run the UGC DTC Lead Scraper',
      desc: 'Executes Google Dorking queries and writes to CSV.',
      cmd: 'python ugc_lead_scraper.py --niche fitness --limit 25 --output fitness_leads.csv'
    }
  ];

  const steps = activeOs === 'mac' ? macSteps : winSteps;

  return (
    <div className="space-y-6">
      {/* OS Selector & Intro Card */}
      <div className="bg-[#0b0b0e] border border-[#E5A823]/30 p-5 rounded-2xl shadow-xl shadow-black">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-black border border-[#E5A823]/40 p-1 flex items-center justify-center shrink-0">
              <Terminal className="w-5 h-5 text-[#E5A823]" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide">
                Terminal Setup & Execution Instructions
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                Run the autonomous scraper directly in your local terminal — 100% free, no paid API keys.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-black border border-zinc-800 rounded-xl">
            <button
              onClick={() => setActiveOs('mac')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                activeOs === 'mac'
                  ? 'bg-[#E5A823] text-black shadow-md shadow-[#E5A823]/20 font-bold'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              macOS / Linux
            </button>
            <button
              onClick={() => setActiveOs('windows')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                activeOs === 'windows'
                  ? 'bg-[#E5A823] text-black shadow-md shadow-[#E5A823]/20 font-bold'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Windows (PowerShell)
            </button>
          </div>
        </div>
      </div>

      {/* Step by step checklist */}
      <div className="space-y-3">
        {steps.map((step, idx) => (
          <div key={idx} className="bg-[#0b0b0e] border border-zinc-800/80 hover:border-[#E5A823]/30 rounded-xl p-4 transition-colors">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <span className="w-5 h-5 rounded bg-[#E5A823]/20 text-[#E5A823] text-[10px] font-mono flex items-center justify-center border border-[#E5A823]/30">
                    {idx + 1}
                  </span>
                  {step.title.replace(/^\d+\.\s*/, '')}
                </h3>
                <p className="text-xs text-zinc-400 mt-1">{step.desc}</p>
              </div>
              <button
                onClick={() => copyCommand(step.cmd, idx)}
                className="px-3 py-1.5 text-xs font-mono bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shrink-0"
              >
                {copiedStep === idx ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400 font-semibold">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>

            <div className="mt-3 bg-black border border-zinc-800 rounded-lg p-2.5 font-mono text-xs text-[#E5A823] flex items-center justify-between overflow-x-auto">
              <code>$ {step.cmd}</code>
            </div>
          </div>
        ))}
      </div>

      {/* Command Line Arguments Reference Table */}
      <div className="bg-[#0b0b0e] border border-[#E5A823]/20 rounded-2xl p-5 shadow-xl">
        <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-4">
          <BookOpen className="w-4 h-4 text-[#E5A823]" />
          CLI Command-Line Arguments Reference
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-zinc-800 text-zinc-400 font-semibold uppercase tracking-wider">
                <th className="py-2.5 px-3">Flag</th>
                <th className="py-2.5 px-3">Default</th>
                <th className="py-2.5 px-3">Description & Example</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-900 text-zinc-300 font-mono">
              <tr>
                <td className="py-3 px-3 text-[#E5A823] font-bold">--niche</td>
                <td className="py-3 px-3 text-zinc-400">skincare</td>
                <td className="py-3 px-3 font-sans text-zinc-300">Target e-commerce niche: <code className="font-mono text-[#E5A823] bg-black px-1.5 py-0.5 rounded border border-zinc-800">--niche supplements</code> or <code className="font-mono text-[#E5A823] bg-black px-1.5 py-0.5 rounded border border-zinc-800">--niche "fitness gear"</code></td>
              </tr>
              <tr>
                <td className="py-3 px-3 text-[#E5A823] font-bold">--limit</td>
                <td className="py-3 px-3 text-zinc-400">15</td>
                <td className="py-3 px-3 font-sans text-zinc-300">Maximum count of unique DTC brands to deep-scrape</td>
              </tr>
              <tr>
                <td className="py-3 px-3 text-[#E5A823] font-bold">--pages</td>
                <td className="py-3 px-3 text-zinc-400">2</td>
                <td className="py-3 px-3 font-sans text-zinc-300">Number of search dork result pagination sets to consume</td>
              </tr>
              <tr>
                <td className="py-3 px-3 text-[#E5A823] font-bold">--output</td>
                <td className="py-3 px-3 text-zinc-400">leads.csv</td>
                <td className="py-3 px-3 font-sans text-zinc-300">Destination path for exported CSV spreadsheet</td>
              </tr>
              <tr>
                <td className="py-3 px-3 text-[#E5A823] font-bold">--playwright</td>
                <td className="py-3 px-3 text-zinc-400">False</td>
                <td className="py-3 px-3 font-sans text-zinc-300">Enables Chromium headless browser to render heavy JavaScript storefronts and dynamic pixels</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Elite Automation Pro Tips */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-[#0b0b0e] border border-zinc-800 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2 text-[#E5A823]">
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Polite Scraping & Anti-Block</h4>
          </div>
          <p className="text-xs text-zinc-400 leading-relaxed">
            The script features built-in randomized request intervals (1.8s - 3.5s jitter) and rotates between Chrome, Safari, and Firefox user-agents. When running large batches of 100+ brands, keep the rate polite to prevent search engine CAPTCHAs.
          </p>
        </div>

        <div className="bg-[#0b0b0e] border border-zinc-800 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2 text-[#E5A823]">
            <Zap className="w-4 h-4 shrink-0" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">AIA Fast-Track Pitch Angle</h4>
          </div>
          <p className="text-xs text-zinc-400 leading-relaxed">
            Target brands with a UGC Opportunity Score &gt; 75. These brands already have active Meta or TikTok ad spend installed but lack video UGC hooks on their product landing pages.
          </p>
        </div>
      </div>
    </div>
  );
};
