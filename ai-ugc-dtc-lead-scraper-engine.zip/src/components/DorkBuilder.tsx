import React, { useState } from 'react';
import { DORK_TEMPLATES, NICHES } from '../data/dorkTemplates';
import { Search, ExternalLink, Copy, Check, Filter, Sparkles } from 'lucide-react';

export const DorkBuilder: React.FC = () => {
  const [selectedNiche, setSelectedNiche] = useState('skincare');
  const [customKeyword, setCustomKeyword] = useState('');
  const [copiedDorkId, setCopiedDorkId] = useState<string | null>(null);

  const activeKeyword = customKeyword.trim() || selectedNiche;

  const handleCopy = (dorkText: string, id: string) => {
    navigator.clipboard.writeText(dorkText);
    setCopiedDorkId(id);
    setTimeout(() => setCopiedDorkId(null), 2000);
  };

  const getDorkQuery = (template: string) => {
    return template.replace(/\{niche\}/g, activeKeyword);
  };

  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const categories = ['ALL', ...Array.from(new Set(NICHES.map(n => n.category)))];
  const displayedNiches = selectedCategory === 'ALL' 
    ? NICHES 
    : NICHES.filter(n => n.category === selectedCategory);

  return (
    <div className="space-y-5">
      {/* Niche Selector & Query Customizer */}
      <div className="bg-[#0b0b0e] border border-[#E5A823]/30 p-5 rounded-2xl shadow-xl shadow-black">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-black border border-[#E5A823]/40 p-1 flex items-center justify-center shrink-0">
            <Search className="w-4 h-4 text-[#E5A823]" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white tracking-wide">
              Google Dorking Engine for DTC Brands (30 High-Potential Niches)
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              These footprint queries locate high-volume Shopify stores, TikTok Shop sellers, and DTC brands with zero paid APIs.
            </p>
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="mt-5 flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#E5A823] text-black shadow-md shadow-[#E5A823]/20 font-bold'
                  : 'bg-black text-zinc-400 hover:text-white border border-zinc-800 hover:border-zinc-700'
              }`}
            >
              {cat === 'ALL' ? 'All 30 Niches' : cat}
            </button>
          ))}
        </div>

        {/* Niche Buttons */}
        <div className="mt-4">
          <label className="text-xs font-semibold uppercase tracking-wider text-zinc-400 block mb-2">
            Select Target Niche ({displayedNiches.length} available):
          </label>
          <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto p-1 scrollbar-thin">
            {displayedNiches.map(n => (
              <button
                key={n.id}
                onClick={() => {
                  setSelectedNiche(n.defaultKeyword || n.id);
                  setCustomKeyword(n.defaultKeyword || '');
                }}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer border ${
                  activeKeyword === (n.defaultKeyword || n.id)
                    ? 'bg-[#E5A823] text-black font-bold border-[#E5A823] shadow-md shadow-[#E5A823]/20'
                    : 'bg-black text-zinc-300 border-zinc-800 hover:bg-zinc-900 hover:border-zinc-700 hover:text-white'
                }`}
                title={n.desc}
              >
                <span>{n.label}</span>
                <span className="text-[10px] text-zinc-500 ml-1.5 opacity-80">({n.defaultKeyword})</span>
              </button>
            ))}
          </div>
        </div>

        {/* Custom Keyword Input */}
        <div className="mt-4 flex flex-col sm:flex-row gap-3">
          <div className="flex-1">
            <label className="text-xs font-semibold uppercase tracking-wider text-zinc-400 block mb-1.5">
              Or Enter Custom Product / Keyword:
            </label>
            <input
              type="text"
              placeholder="e.g. matcha, led face mask, barefoot shoes, mushroom coffee..."
              value={customKeyword}
              onChange={(e) => setCustomKeyword(e.target.value)}
              className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#E5A823] focus:ring-1 focus:ring-[#E5A823]"
            />
          </div>
        </div>
      </div>

      {/* Dork Query Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {DORK_TEMPLATES.map((item) => {
          const generatedQuery = getDorkQuery(item.dork);
          const googleUrl = `https://www.google.com/search?q=${encodeURIComponent(generatedQuery)}`;
          const ddgUrl = `https://duckduckgo.com/?q=${encodeURIComponent(generatedQuery)}`;

          return (
            <div key={item.id} className="bg-[#0b0b0e] border border-zinc-800/80 hover:border-[#E5A823]/40 rounded-xl p-4 flex flex-col justify-between transition-colors shadow-lg">
              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="text-xs font-bold text-white">{item.title}</span>
                  <span className="text-[10px] font-semibold text-[#E5A823] bg-black border border-[#E5A823]/30 px-2 py-0.5 rounded font-mono">
                    {item.platform}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mb-3">{item.purpose}</p>

                <div className="bg-black border border-zinc-800 rounded-lg p-2.5 font-mono text-[11px] text-[#E5A823] break-all select-all">
                  {generatedQuery}
                </div>
              </div>

              <div className="flex items-center justify-between gap-2 mt-3 pt-3 border-t border-zinc-900">
                <button
                  onClick={() => handleCopy(generatedQuery, item.id)}
                  className="px-2.5 py-1 text-xs font-medium rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  {copiedDorkId === item.id ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" />
                      <span className="text-emerald-400 font-semibold">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Copy Query</span>
                    </>
                  )}
                </button>

                <div className="flex items-center gap-2">
                  <a
                    href={ddgUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-2.5 py-1 text-xs font-semibold text-zinc-300 hover:text-black hover:bg-[#E5A823] rounded-lg border border-zinc-800 hover:border-[#E5A823] transition-all flex items-center gap-1"
                  >
                    DuckDuckGo
                    <ExternalLink className="w-2.5 h-2.5" />
                  </a>
                  <a
                    href={googleUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-2.5 py-1 text-xs font-semibold text-zinc-300 hover:text-black hover:bg-[#E5A823] rounded-lg border border-zinc-800 hover:border-[#E5A823] transition-all flex items-center gap-1"
                  >
                    Google
                    <ExternalLink className="w-2.5 h-2.5" />
                  </a>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
