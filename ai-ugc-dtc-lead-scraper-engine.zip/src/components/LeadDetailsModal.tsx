import React from 'react';
import { LeadRecord } from '../types/scraper';
import { X, ExternalLink, Mail, Video, ShieldCheck, Tag, Globe, Sparkles, Copy, Check } from 'lucide-react';

interface LeadDetailsModalProps {
  lead: LeadRecord | null;
  onClose: () => void;
  onOpenPitch: (lead: LeadRecord) => void;
}

export const LeadDetailsModal: React.FC<LeadDetailsModalProps> = ({ lead, onClose, onOpenPitch }) => {
  const [copied, setCopied] = React.useState(false);

  if (!lead) return null;

  const handleCopyJSON = () => {
    navigator.clipboard.writeText(JSON.stringify(lead, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xs">
      <div className="bg-[#0b0b0e] border border-[#E5A823]/30 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl shadow-black">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-[#E5A823]/20 bg-[#070709]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-black border border-[#E5A823]/40 p-1 flex items-center justify-center">
              <img 
                src="/assets/aistudio/AIA-5_b1617e8d.png" 
                alt="AIA Logo" 
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-wide">{lead.brandName}</h2>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-[#E5A823]/10 text-[#E5A823] border border-[#E5A823]/30">
                  {lead.niche}
                </span>
                {lead.hasShopify && (
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    Shopify DTC
                  </span>
                )}
              </div>
              <a
                href={lead.websiteUrl}
                target="_blank"
                rel="noreferrer"
                className="text-xs text-[#E5A823] hover:underline flex items-center gap-1 mt-0.5"
              >
                {lead.websiteUrl}
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-900 border border-transparent hover:border-zinc-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 overflow-y-auto">
          {/* UGC Ad Opportunity Score */}
          <div className="bg-gradient-to-r from-black via-zinc-950 to-black border border-[#E5A823]/30 rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-[#E5A823] flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#E5A823]" />
                AI UGC Qualification Signals
              </span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-[#E5A823]/20 text-[#E5A823] border border-[#E5A823]/40">
                High Priority Agency Lead
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-zinc-900/80 p-3 rounded-lg border border-zinc-800">
                <span className="text-[10px] uppercase font-medium text-zinc-400 block mb-1">Video Embeds</span>
                <span className="text-xs font-semibold text-zinc-200">
                  {lead.videoEmbedsDetected ? 'Detected (TikTok/Reels widgets)' : 'None found (Huge Gap!)'}
                </span>
              </div>
              <div className="bg-zinc-900/80 p-3 rounded-lg border border-zinc-800">
                <span className="text-[10px] uppercase font-medium text-zinc-400 block mb-1">Social Proof App</span>
                <span className="text-xs font-semibold text-zinc-200">{lead.reviewAppsDetected}</span>
              </div>
              <div className="bg-zinc-900/80 p-3 rounded-lg border border-zinc-800">
                <span className="text-[10px] uppercase font-medium text-zinc-400 block mb-1">Meta Ads Status</span>
                <a
                  href={lead.metaAdLibraryUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs font-semibold text-[#E5A823] hover:underline flex items-center gap-1"
                >
                  Inspect Ad Library <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>

            <div className="mt-3 p-2.5 rounded bg-black/60 border border-zinc-800 text-xs text-zinc-300">
              <strong className="text-[#E5A823]">AIA Agency Angle: </strong>
              {lead.ugcSignalsDetected}
            </div>
          </div>

          {/* Contact Details */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-3 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-[#E5A823]" />
              Direct Contact & Outreach Routing
            </h3>
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl divide-y divide-zinc-800">
              <div className="p-3 flex items-center justify-between">
                <span className="text-xs text-zinc-400">Primary Outreach Email</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-semibold text-[#E5A823]">{lead.primaryEmail}</span>
                  <a
                    href={`mailto:${lead.primaryEmail}`}
                    className="p-1 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded transition-colors"
                    title="Send Email"
                  >
                    <Mail className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {lead.allEmails && lead.allEmails.length > 1 && (
                <div className="p-3 flex items-center justify-between">
                  <span className="text-xs text-zinc-400">Alternative Inboxes</span>
                  <span className="font-mono text-xs text-zinc-300">{lead.allEmails.join(', ')}</span>
                </div>
              )}

              <div className="p-3 flex items-center justify-between">
                <span className="text-xs text-zinc-400">Contact / Press Pages</span>
                <div className="flex flex-wrap gap-1.5 justify-end">
                  {lead.contactPages.length > 0 ? (
                    lead.contactPages.map((page, i) => (
                      <a
                        key={i}
                        href={page}
                        target="_blank"
                        rel="noreferrer"
                        className="text-xs font-mono text-[#E5A823] hover:underline bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800 flex items-center gap-1"
                      >
                        {page.replace(/^https?:\/\/[^/]+/, '') || '/'}
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    ))
                  ) : (
                    <span className="text-xs text-zinc-500">None detected</span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Social Profiles */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-3 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-[#E5A823]" />
              Social Handles & Ad Channels
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl flex items-center justify-between">
                <span className="text-xs text-zinc-400">Instagram</span>
                {lead.instagram ? (
                  <a
                    href={lead.instagram}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs font-semibold text-[#E5A823] hover:underline flex items-center gap-1"
                  >
                    @{lead.instagram.replace(/^https?:\/\/(www\.)?instagram\.com\//, '').replace(/\/$/, '')}
                    <ExternalLink className="w-3 h-3" />
                  </a>
                ) : (
                  <span className="text-xs text-zinc-500">Not found</span>
                )}
              </div>

              <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl flex items-center justify-between">
                <span className="text-xs text-zinc-400">TikTok</span>
                {lead.tiktok ? (
                  <a
                    href={lead.tiktok}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs font-semibold text-[#E5A823] hover:underline flex items-center gap-1"
                  >
                    @{lead.tiktok.replace(/^https?:\/\/(www\.)?tiktok\.com\/@?/, '').replace(/\/$/, '')}
                    <ExternalLink className="w-3 h-3" />
                  </a>
                ) : (
                  <span className="text-xs text-zinc-500">Not found</span>
                )}
              </div>
            </div>
          </div>

          {/* Dork Discovery Metadata */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-2">Discovery Dork Footprint</h3>
            <div className="font-mono text-xs bg-black text-zinc-300 p-3 rounded-lg border border-zinc-800 break-all">
              {lead.discoveryQuery}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#070709] border-t border-[#E5A823]/20 flex items-center justify-between">
          <button
            onClick={handleCopyJSON}
            className="px-3 py-1.5 text-xs font-medium rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-700 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copied Lead JSON' : 'Copy Lead JSON'}
          </button>

          <div className="flex items-center gap-2">
            <a
              href={lead.websiteUrl}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 text-xs font-medium rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <ExternalLink className="w-3 h-3" />
              Visit Storefront
            </a>

            <button
              onClick={() => {
                onClose();
                onOpenPitch(lead);
              }}
              className="px-4 py-1.5 text-xs font-bold rounded-lg bg-[#E5A823] hover:bg-[#F5B82E] text-black transition-all flex items-center gap-1.5 cursor-pointer shadow-md shadow-[#E5A823]/20"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Generate Cold Pitch
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
