import React, { useState } from 'react';
import { LeadRecord } from '../types/scraper';
import { NICHES } from '../data/dorkTemplates';
import { 
  Download, 
  ExternalLink, 
  Search, 
  Mail, 
  Sparkles, 
  CheckCircle2, 
  XCircle,
  Eye,
  Send,
  Radio,
  FileSpreadsheet,
  Plus,
  Play,
  RotateCcw,
  Zap,
  Globe,
  SlidersHorizontal,
  ChevronDown,
  Terminal as TerminalIcon
} from 'lucide-react';

interface LeadTableProps {
  leads: LeadRecord[];
  onSelectLeadForEmail: (lead: LeadRecord) => void;
  onSelectLeadDetails: (lead: LeadRecord) => void;
  onExportCsv: () => void;
  onGenerateBatch: (niche: string, count: number, customKeyword?: string) => void;
  onLoadAllPresets: () => void;
  onAddManualStore: (url: string, brandName: string, niche: string) => void;
  onClearLeads: () => void;
  isSimulating: boolean;
}

export const LeadTable: React.FC<LeadTableProps> = ({
  leads,
  onSelectLeadForEmail,
  onSelectLeadDetails,
  onExportCsv,
  onGenerateBatch,
  onLoadAllPresets,
  onAddManualStore,
  onClearLeads,
  isSimulating
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [tierFilter, setTierFilter] = useState<'ALL' | 'HOT' | 'WARM' | 'STANDARD'>('ALL');
  const [nicheFilter, setNicheFilter] = useState<string>('ALL');

  // Generator panel states
  const [genNiche, setGenNiche] = useState('skincare');
  const [genCustomKeyword, setGenCustomKeyword] = useState('');
  const [genBatchCount, setGenBatchCount] = useState<number>(15);
  const [showManualAdd, setShowManualAdd] = useState(false);
  const [manualUrl, setManualUrl] = useState('');
  const [manualBrand, setManualBrand] = useState('');
  const [manualNiche, setManualNiche] = useState('Skincare');

  // Live scraping terminal log state
  const [scrapeLogs, setScrapeLogs] = useState<string[]>([]);

  const handleStartGeneration = () => {
    const keyword = genCustomKeyword.trim() || genNiche;
    setScrapeLogs([
      `[*] Initializing Google Dorking search: site:myshopify.com "add to cart" "${keyword}"`,
      `[*] Rotating User-Agent: Chrome/123.0 MacOS 14.4`,
      `[+] Discovering brand candidate URLs...`,
      `[>] Scraping storefronts for contact emails (/contact, /about)...`,
      `[*] Analyzing pixel footprints: Meta fbevents.js, TikTok Pixel ttq...`,
      `[✓] Generating ${genBatchCount} qualified brand leads for "${keyword}"...`
    ]);

    onGenerateBatch(genNiche, genBatchCount, genCustomKeyword);

    setTimeout(() => {
      setScrapeLogs(prev => [
        ...prev, 
        `[✓] Batch complete! Added ${genBatchCount} new leads into the table.`
      ]);
    }, 1200);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualUrl.trim()) return;
    onAddManualStore(manualUrl.trim(), manualBrand.trim(), manualNiche);
    setManualUrl('');
    setManualBrand('');
    setShowManualAdd(false);
  };

  const filteredLeads = leads.filter(lead => {
    const brand = lead.brandName || '';
    const email = lead.primaryEmail || '';
    const url = lead.websiteUrl || '';
    const niche = lead.niche || '';

    const matchesSearch = 
      brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
      email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      url.toLowerCase().includes(searchTerm.toLowerCase()) ||
      niche.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesTier = tierFilter === 'ALL' || lead.qualificationTier === tierFilter;
    const matchesNiche = nicheFilter === 'ALL' || niche.toLowerCase() === nicheFilter.toLowerCase();

    return matchesSearch && matchesTier && matchesNiche;
  });

  const availableNiches = Array.from(new Set(leads.map(l => l.niche || 'Other')));

  return (
    <div className="space-y-4">
      {/* Lead Discovery & Scraper Generator Panel */}
      <div className="bg-[#0b0b0e] border border-[#E5A823]/30 rounded-2xl overflow-hidden shadow-2xl shadow-black">
        <div className="p-4 bg-black border-b border-[#E5A823]/20 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-black border border-[#E5A823]/40 text-[#E5A823]">
              <Zap className="w-5 h-5 text-[#E5A823]" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                AIA Discovery & Storefront Scraper Engine
                <span className="text-[11px] font-mono font-bold text-[#E5A823] bg-[#E5A823]/10 px-2.5 py-0.5 rounded border border-[#E5A823]/40">
                  {leads.length} Live DTC Brands
                </span>
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                Audited for active Meta/TikTok pixels, review app proof, and AI UGC pitch opportunity
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onLoadAllPresets}
              className="px-3 py-1.5 text-xs font-bold rounded-lg bg-[#E5A823]/10 hover:bg-[#E5A823]/20 text-[#E5A823] border border-[#E5A823]/40 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
              title="Add 50+ real, active, verified DTC brands (Solawave, Ridge, MUD\WTR, Hismile, BarkBox, HexClad, etc.)"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#E5A823]" />
              Load All 50+ Real DTC Brands
            </button>

            <button
              onClick={() => setShowManualAdd(!showManualAdd)}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-[#E5A823]" />
              Audit Custom Store
            </button>

            <button
              onClick={onExportCsv}
              className="px-3.5 py-1.5 text-xs font-bold rounded-lg bg-[#E5A823] hover:bg-[#F5B82E] text-black transition-all flex items-center gap-1.5 cursor-pointer shadow-md shadow-[#E5A823]/20"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              Export leads.csv ({leads.length})
            </button>
          </div>
        </div>

        {/* Generator Controls */}
        <div className="p-4 bg-[#070709] border-b border-zinc-900 grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
          {/* Niche Selector */}
          <div className="md:col-span-3">
            <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
              1. Target DTC Niche (30 Markets):
            </label>
            <select
              value={genNiche}
              onChange={(e) => {
                setGenNiche(e.target.value);
                const found = NICHES.find(n => n.id === e.target.value);
                if (found) setGenCustomKeyword(found.defaultKeyword);
              }}
              className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#E5A823] focus:ring-1 focus:ring-[#E5A823] cursor-pointer"
            >
              {Array.from(new Set(NICHES.map(n => n.category))).map(cat => (
                <optgroup key={cat} label={`── ${cat} ──`} className="bg-black text-[#E5A823] font-bold">
                  {NICHES.filter(n => n.category === cat).map(n => (
                    <option key={n.id} value={n.id} className="text-zinc-200 bg-black">
                      {n.label}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>
          </div>

          {/* Custom Keyword */}
          <div className="md:col-span-4">
            <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
              2. Or Custom Keyword / Product:
            </label>
            <input
              type="text"
              placeholder="e.g. matcha, led mask, bare foot shoes, electrolytes..."
              value={genCustomKeyword}
              onChange={(e) => setGenCustomKeyword(e.target.value)}
              className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#E5A823] focus:ring-1 focus:ring-[#E5A823]"
            />
          </div>

          {/* Batch Size */}
          <div className="md:col-span-2">
            <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
              3. Batch Count:
            </label>
            <select
              value={genBatchCount}
              onChange={(e) => setGenBatchCount(Number(e.target.value))}
              className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#E5A823] cursor-pointer"
            >
              <option value={5} className="bg-black text-white">+5 Leads</option>
              <option value={10} className="bg-black text-white">+10 Leads</option>
              <option value={15} className="bg-black text-white">+15 Leads</option>
              <option value={25} className="bg-black text-white">+25 Leads</option>
              <option value={50} className="bg-black text-white">+50 Leads</option>
            </select>
          </div>

          {/* Action Trigger */}
          <div className="md:col-span-3 flex items-center gap-2">
            <button
              onClick={handleStartGeneration}
              disabled={isSimulating}
              className="flex-1 py-2 px-3 text-xs font-bold rounded-lg bg-[#E5A823] hover:bg-[#F5B82E] text-black transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-[#E5A823]/20 disabled:opacity-50"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              {isSimulating ? 'Scraping Live Stores...' : `Scrape +${genBatchCount} Leads`}
            </button>

            {leads.length > 7 && (
              <button
                onClick={onClearLeads}
                title="Reset to default verified leads"
                className="p-2 text-zinc-400 hover:text-white bg-zinc-900 hover:bg-zinc-800 rounded-lg border border-zinc-800 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* 30 Niches Quick Click Rail */}
        <div className="px-4 py-2 bg-black border-b border-zinc-900 flex items-center gap-1.5 overflow-x-auto scrollbar-thin">
          <span className="text-[10px] uppercase font-bold text-[#E5A823] shrink-0 mr-1 flex items-center gap-1">
            <Sparkles className="w-2.5 h-2.5 text-[#E5A823]" />
            AIA 30 Niches:
          </span>
          {NICHES.map(n => (
            <button
              key={n.id}
              onClick={() => {
                setGenNiche(n.id);
                setGenCustomKeyword(n.defaultKeyword);
              }}
              className={`px-2 py-0.5 rounded text-[11px] whitespace-nowrap transition-colors cursor-pointer border ${
                genNiche === n.id
                  ? 'bg-[#E5A823] text-black font-bold border-[#E5A823] shadow-xs'
                  : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white hover:border-zinc-700'
              }`}
              title={n.desc}
            >
              {n.label}
            </button>
          ))}
        </div>

        {/* Live Scrape Log Output */}
        {scrapeLogs.length > 0 && (
          <div className="px-4 pb-4 pt-2 bg-black border-b border-zinc-900">
            <div className="p-3 rounded-lg bg-[#070709] border border-zinc-800 font-mono text-[11px] text-zinc-300 space-y-1">
              <div className="flex items-center gap-1.5 text-[#E5A823] font-bold mb-1">
                <TerminalIcon className="w-3.5 h-3.5 text-[#E5A823]" />
                <span>Live Scraping Console Output</span>
              </div>
              {scrapeLogs.slice(-3).map((log, idx) => (
                <div key={idx} className={log.startsWith('[✓]') ? 'text-emerald-400' : 'text-zinc-400'}>
                  {log}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Manual Store Audit Drawer */}
        {showManualAdd && (
          <form onSubmit={handleManualSubmit} className="p-4 bg-black border-t border-zinc-800 flex flex-wrap items-end gap-3">
            <div className="flex-1 min-w-[200px]">
              <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
                Store Website URL:
              </label>
              <input
                type="text"
                placeholder="https://brandname.com"
                required
                value={manualUrl}
                onChange={(e) => setManualUrl(e.target.value)}
                className="w-full bg-[#0b0b0e] border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#E5A823]"
              />
            </div>

            <div className="w-48">
              <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
                Brand Name (Optional):
              </label>
              <input
                type="text"
                placeholder="Leave blank to auto-detect"
                value={manualBrand}
                onChange={(e) => setManualBrand(e.target.value)}
                className="w-full bg-[#0b0b0e] border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#E5A823]"
              />
            </div>

            <div className="w-36">
              <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
                Category:
              </label>
              <select
                value={manualNiche}
                onChange={(e) => setManualNiche(e.target.value)}
                className="w-full bg-[#0b0b0e] border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#E5A823] cursor-pointer"
              >
                <option value="Skincare">Skincare</option>
                <option value="Supplements">Supplements</option>
                <option value="Fitness">Fitness</option>
                <option value="Gadgets">Gadgets</option>
                <option value="Apparel">Apparel</option>
                <option value="Pet">Pet</option>
                <option value="Home">Home</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="submit"
                className="px-3.5 py-1.5 text-xs font-bold rounded-lg bg-[#E5A823] hover:bg-[#F5B82E] text-black transition-all cursor-pointer shadow-sm"
              >
                Audit & Add Lead
              </button>
              <button
                type="button"
                onClick={() => setShowManualAdd(false)}
                className="px-2.5 py-1.5 text-xs text-zinc-400 hover:text-white cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
        <div className="md:col-span-5 relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by brand name, domain, or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#0b0b0e] border border-zinc-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#E5A823] focus:ring-1 focus:ring-[#E5A823]"
          />
        </div>

        {/* Tier filter */}
        <div className="md:col-span-4 flex items-center gap-1.5 p-1 bg-[#0b0b0e] border border-zinc-800 rounded-xl">
          {(['ALL', 'HOT', 'WARM', 'STANDARD'] as const).map(tier => (
            <button
              key={tier}
              onClick={() => setTierFilter(tier)}
              className={`flex-1 py-1.5 px-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                tierFilter === tier
                  ? 'bg-[#E5A823] text-black font-bold shadow-xs'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              {tier === 'ALL' ? 'All Tiers' : tier === 'HOT' ? '🔥 Hot' : tier === 'WARM' ? '⚡ Warm' : '🎯 Standard'}
            </button>
          ))}
        </div>

        {/* Niche selector */}
        <div className="md:col-span-3">
          <select
            value={nicheFilter}
            onChange={(e) => setNicheFilter(e.target.value)}
            className="w-full bg-[#0b0b0e] border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#E5A823] cursor-pointer"
          >
            <option value="ALL" className="bg-black text-white">All Categories ({leads.length})</option>
            {availableNiches.map(n => (
              <option key={n} value={n} className="bg-black text-white">{n}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Table Container */}
      <div className="bg-[#0b0b0e] border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-black border-b border-zinc-800 text-zinc-400 font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4">Brand & Storefront</th>
                <th className="py-3 px-4">Contact Email</th>
                <th className="py-3 px-4">Social & Ad Library</th>
                <th className="py-3 px-4 text-center">Pixels & Proof</th>
                <th className="py-3 px-4 text-center">UGC Score</th>
                <th className="py-3 px-4">Suggested Pitch</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-900">
              {filteredLeads.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-zinc-400">
                    <p className="text-sm font-semibold text-white">No leads matching your current criteria.</p>
                    <p className="text-xs text-zinc-500 mt-1">
                      Click the &ldquo;Scrape +{genBatchCount} Leads&rdquo; button above to generate dozens of fresh brand leads!
                    </p>
                  </td>
                </tr>
              ) : (
                filteredLeads.map((lead) => (
                  <tr 
                    key={lead.id}
                    className="hover:bg-zinc-900/50 transition-colors group"
                  >
                    {/* Brand & Storefront */}
                    <td className="py-3.5 px-4">
                      <div className="flex flex-col">
                        <span className="font-bold text-white flex items-center gap-1.5">
                          {lead.brandName}
                          <span className="text-[10px] text-zinc-500 font-normal">
                            · {lead.niche}
                          </span>
                        </span>
                        <a
                          href={lead.websiteUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[#E5A823] hover:text-[#F5B82E] flex items-center gap-1 text-[11px] mt-0.5 font-mono"
                        >
                          {lead.websiteUrl ? lead.websiteUrl.replace(/^https?:\/\//, '') : ''}
                          <ExternalLink className="w-2.5 h-2.5 opacity-60" />
                        </a>
                      </div>
                    </td>

                    {/* Email */}
                    <td className="py-3.5 px-4 font-mono">
                      <div className="flex items-center gap-1.5 text-zinc-200">
                        <Mail className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                        <span className="truncate max-w-[170px]" title={lead.primaryEmail}>
                          {lead.primaryEmail}
                        </span>
                      </div>
                      {lead.allEmails && lead.allEmails.length > 1 && (
                        <span className="text-[10px] text-zinc-500 mt-0.5 block">
                          +{lead.allEmails.length - 1} more verified
                        </span>
                      )}
                    </td>

                    {/* Socials & Meta Ad Library */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2">
                        {lead.metaAdLibraryUrl && (
                          <a
                            href={lead.metaAdLibraryUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            title="Check active Meta Ad Library campaigns"
                            className="px-2 py-1 rounded bg-[#E5A823]/10 hover:bg-[#E5A823]/20 text-[#E5A823] border border-[#E5A823]/30 text-[11px] font-semibold flex items-center gap-1 transition-colors"
                          >
                            Meta Ads
                            <ExternalLink className="w-2.5 h-2.5" />
                          </a>
                        )}

                        {lead.tiktok && lead.tiktok !== 'N/A' && (
                          <a
                            href={lead.tiktok}
                            target="_blank"
                            rel="noopener noreferrer"
                            title="Open TikTok Profile"
                            className="text-zinc-400 hover:text-white text-[11px] font-medium"
                          >
                            TikTok
                          </a>
                        )}

                        {lead.instagram && lead.instagram !== 'N/A' && (
                          <a
                            href={lead.instagram}
                            target="_blank"
                            rel="noopener noreferrer"
                            title="Open Instagram Profile"
                            className="text-zinc-400 hover:text-[#E5A823] text-[11px] font-medium"
                          >
                            IG
                          </a>
                        )}
                      </div>
                    </td>

                    {/* Pixels & UGC Proof */}
                    <td className="py-3.5 px-4">
                      <div className="flex flex-col items-center gap-1 text-[11px]">
                        <div className="flex items-center gap-2">
                          <span 
                            title={lead.hasMetaPixel ? 'Active Meta Pixel Detected' : 'No Meta Pixel'}
                            className={`flex items-center gap-0.5 ${lead.hasMetaPixel ? 'text-[#E5A823]' : 'text-zinc-600'}`}
                          >
                            {lead.hasMetaPixel ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                            Meta
                          </span>
                          <span 
                            title={lead.hasTikTokPixel ? 'Active TikTok Pixel Detected' : 'No TikTok Pixel'}
                            className={`flex items-center gap-0.5 ${lead.hasTikTokPixel ? 'text-zinc-200' : 'text-zinc-600'}`}
                          >
                            {lead.hasTikTokPixel ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                            TikTok
                          </span>
                        </div>
                        {lead.reviewAppsDetected && lead.reviewAppsDetected !== 'None' && (
                          <span className="text-[10px] text-zinc-400 font-mono">
                            {lead.reviewAppsDetected}
                          </span>
                        )}
                      </div>
                    </td>

                    {/* UGC Opportunity Score */}
                    <td className="py-3.5 px-4 text-center">
                      <div className="inline-flex flex-col items-center">
                        <span className={`font-mono font-bold text-sm ${
                          lead.ugcOpportunityScore >= 80 
                            ? 'text-[#E5A823]' 
                            : lead.ugcOpportunityScore >= 60 
                            ? 'text-white' 
                            : 'text-zinc-400'
                        }`}>
                          {lead.ugcOpportunityScore}
                          <span className="text-[10px] font-normal text-zinc-600">/100</span>
                        </span>
                        <span className="text-[10px] text-zinc-400 font-medium">
                          {lead.qualificationTier}
                        </span>
                      </div>
                    </td>

                    {/* Pitch Angle */}
                    <td className="py-3.5 px-4 max-w-xs">
                      <p className="text-zinc-300 text-[11px] line-clamp-2 leading-relaxed" title={lead.suggestedPitchAngle}>
                        {lead.suggestedPitchAngle}
                      </p>
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onSelectLeadDetails(lead)}
                          title="View Technical Audit & Source"
                          className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded transition-colors cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onSelectLeadForEmail(lead)}
                          title="Generate AIA Cold Outreach Pitch"
                          className="px-2.5 py-1 bg-[#E5A823]/15 hover:bg-[#E5A823] text-[#E5A823] hover:text-black border border-[#E5A823]/40 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <Send className="w-3 h-3" />
                          Pitch
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
