import React, { useState } from 'react';
import { Terminal, Download, Copy, Check, FileCode, Play, Sparkles } from 'lucide-react';

interface ScriptViewerProps {
  onBackToLeads?: () => void;
}

export const ScriptViewer: React.FC<ScriptViewerProps> = () => {
  const [activeTab, setActiveTab] = useState<'script' | 'setup' | 'dorks'>('script');
  const [copied, setCopied] = useState(false);

  const pythonScript = `#!/usr/bin/env python3
"""
=============================================================================
AIA MEDIA | AI UGC AD AGENCY LEAD ENGINE & DTC DISCOVERY SCRAPER
=============================================================================
Free, autonomous Python script to discover high-growth Shopify & DTC brands
across 30 high-potential e-commerce niches and qualify them for AI UGC ad deals.

No Paid APIs Required. Uses Google/DuckDuckGo dorking, polite rate limiting,
anti-detection User-Agent rotation, social handle discovery, and CSV export.
=============================================================================
"""

import os
import re
import csv
import time
import random
import logging
from typing import List, Dict, Optional, Set
from urllib.parse import urlparse, urljoin
import requests
from bs4 import BeautifulSoup

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger("AIA-LeadScraper")

# User-Agent rotation pool for anti-detection
USER_AGENTS = [
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
]

# 30 Targeted DTC Niches for AI UGC Ad Pitching
TARGET_NICHES = [
    "Skincare & Serums", "Mushroom Coffee & Nootropics", "Cold Plunge & Recovery",
    "Smart Rings & Health Wearables", "Barefoot & Minimalist Shoes", "Red Light Therapy",
    "Luxury Cookware", "Hair Growth & Scalp Care", "Hydration & Electrolytes",
    "Pet Longevity & Supplements", "Teeth Whitening", "Mouth Tape & Sleep",
    "Greens Powders & Superfoods", "Non-Alcoholic Beverages", "Functional Mushrooms",
    "Everyday Carry & Minimalist Wallets", "Ergonomic & Standing Workspaces", "Activewear & Athleisure",
    "Zero-Drop Running Shoes", "Weighted Blankets & Deep Sleep", "Clean Fragrance & Perfume",
    "Body Grooming & Trimmers", "Premium Travel Luggage", "Smart Plant Care & Hydroponics",
    "Clean Laundry Detergent Sheets", "High-Protein Snacks & Bars", "Blue Light & Screen Eyewear",
    "Cast Iron & Carbon Steel Pans", "Smart Water Bottles", "Magnesium & Sleep Gummies"
]

class AIAUgcLeadScraper:
    def __init__(self, output_file: str = "leads.csv", delay_range: tuple = (2.0, 4.5)):
        self.output_file = output_file
        self.delay_range = delay_range
        self.session = requests.Session()
        self.discovered_domains: Set[str] = set()

    def get_headers(self) -> dict:
        return {
            "User-Agent": random.choice(USER_AGENTS),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        }

    def execute_duckduckgo_dork(self, query: str, max_results: int = 15) -> List[str]:
        """Free web discovery without paid SERP APIs."""
        logger.info(f"Dorking query: {query}")
        url = "https://html.duckduckgo.com/html/"
        headers = self.get_headers()
        domains = []
        try:
            resp = self.session.post(url, data={"q": query}, headers=headers, timeout=12)
            if resp.status_code == 200:
                soup = BeautifulSoup(resp.text, 'html.parser')
                links = soup.find_all('a', class_='result__url')
                for link in links:
                    href = link.get('href', '').strip()
                    if href.startswith('//'):
                        href = 'https:' + href
                    elif not href.startswith('http'):
                        href = 'https://' + href
                    domain = urlparse(href).netloc.lower()
                    if domain and not any(blocked in domain for blocked in ['duckduckgo', 'myshopify.com', 'google', 'facebook', 'instagram', 'tiktok', 'youtube', 'amazon']):
                        clean_url = f"https://{domain}"
                        if clean_url not in domains:
                            domains.append(clean_url)
            time.sleep(random.uniform(*self.delay_range))
        except Exception as e:
            logger.warning(f"Error querying DuckDuckGo: {e}")
        return domains[:max_results]

    def scrape_storefront(self, base_url: str, niche: str) -> Optional[Dict]:
        """Scrapes contact info, social links, and qualifies site for AI UGC ads."""
        headers = self.get_headers()
        try:
            resp = self.session.get(base_url, headers=headers, timeout=10)
            if resp.status_code != 200:
                return None
            soup = BeautifulSoup(resp.text, 'html.parser')
            html_text = resp.text

            # Extract brand name
            og_site_name = soup.find('meta', property='og:site_name')
            brand_name = og_site_name['content'].strip() if og_site_name and og_site_name.get('content') else None
            if not brand_name:
                title = soup.find('title')
                brand_name = title.text.split('|')[0].split('-')[0].strip() if title else urlparse(base_url).netloc

            # Detect Shopify
            has_shopify = "cdn.shopify.com" in html_text or "window.Shopify" in html_text

            # Regex search for emails
            email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
            emails = set(re.findall(email_pattern, html_text))
            clean_emails = [e for e in emails if not any(x in e.lower() for x in ['.png', '.jpg', '.webp', 'sentry', 'wix', 'example', 'schema'])]

            # Social links
            instagram, tiktok = "", ""
            for a in soup.find_all('a', href=True):
                href = a['href']
                if 'instagram.com/' in href and not instagram:
                    instagram = href
                if 'tiktok.com/' in href and not tiktok:
                    tiktok = href

            # UGC qualification check
            video_widgets = any(w in html_text.lower() for w in ['tiktok-widget', 'videowise', 'tolstoy', 'bounty', 'loox', 'judge.me', 'okendo'])
            ugc_mentions = bool(re.search(r'\\b(ugc|creator|ambassador|affiliate|tag us)\\b', html_text, re.IGNORECASE))

            return {
                "Brand Name": brand_name,
                "Website URL": base_url,
                "Primary Email": clean_emails[0] if clean_emails else "contact@" + urlparse(base_url).netloc.replace("www.", ""),
                "Niche": niche,
                "Shopify DTC": "Yes" if has_shopify else "No",
                "Video / UGC Signals": "Active UGC / Video Widgets" if (video_widgets or ugc_mentions) else "Static Only (Needs AI UGC)",
                "Instagram": instagram,
                "TikTok": tiktok,
                "Meta Ad Library": f"https://www.facebook.com/ads/library/?active_status=all&ad_type=all&country=ALL&q={urlparse(base_url).netloc}"
            }
        except Exception as e:
            logger.debug(f"Failed to scrape {base_url}: {e}")
            return None

    def run(self, max_leads: int = 50):
        print("⚡ AIA Media | AI UGC Lead Scraper Starting...")
        leads = []
        for niche in TARGET_NICHES:
            if len(leads) >= max_leads:
                break
            query = f'site:myshopify.com "add to cart" "{niche}"'
            urls = self.execute_duckduckgo_dork(query, max_results=5)
            for url in urls:
                if url in self.discovered_domains:
                    continue
                self.discovered_domains.add(url)
                logger.info(f"Auditing store: {url} ({niche})")
                data = self.scrape_storefront(url, niche)
                if data:
                    leads.append(data)
                    logger.info(f"✅ Discovered Lead: {data['Brand Name']} <{data['Primary Email']}>")
                time.sleep(random.uniform(*self.delay_range))

        # Write to CSV
        if leads:
            with open(self.output_file, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=leads[0].keys())
                writer.writeheader()
                writer.writerows(leads)
            print(f"\\n🎯 Successfully exported {len(leads)} qualified DTC leads to {self.output_file}")

if __name__ == "__main__":
    scraper = AIAUgcLeadScraper(output_file="leads.csv")
    scraper.run(max_leads=30)
`;

  const setupCommands = `# 1. Create and activate a clean virtual environment
python3 -m venv venv
source venv/bin/activate    # On Windows use: venv\\Scripts\\activate

# 2. Install free open-source dependencies (Zero Paid APIs)
pip install requests beautifulsoup4 playwright

# 3. Optional: Install Playwright browser drivers for dynamic SPA rendering
playwright install chromium

# 4. Run the scraper
python ugc_lead_scraper.py

# 5. Output leads will be automatically saved to leads.csv!
cat leads.csv | head -n 10
`;

  const dorkCheatSheet = `# High-Converting Google Dorking Footprints for DTC Brands

# 1. Shopify Storefronts with Cart & Niche Keywords
site:myshopify.com "add to cart" "skincare"
site:myshopify.com "free shipping" "mushroom coffee"
site:myshopify.com "powered by shopify" "cold plunge"

# 2. Brands Actively Recruiting Creators / Ambassadors (Prime AI UGC targets!)
site:myshopify.com inurl:pages/ambassador "ugc"
site:myshopify.com inurl:pages/creators "collab"
site:myshopify.com intext:"content creator program" "dtc"

# 3. Brands Using High-End Social Proof & Review Widgets
inurl:collections/all "powered by okendo" "fitness"
inurl:products/ "reviews powered by loox" "supplements"
inurl:products/ "judge.me review" "smart ring"

# 4. TikTok Shop / DTC Video Discovery
inurl:collections/all "tiktok shop" "apparel"
site:myshopify.com "as seen on tiktok" "gadgets"
`;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-black via-zinc-950 to-black border border-[#E5A823]/30 rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-black border border-[#E5A823]/40 p-1.5 flex items-center justify-center shrink-0">
              <img 
                src="/assets/aistudio/AIA-5_b1617e8d.png" 
                alt="AIA Logo" 
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-wide">
                  Autonomous Python Scraper & Terminal Engine
                </h2>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-[#E5A823]/20 text-[#E5A823] border border-[#E5A823]/40">
                  100% Free
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-1 max-w-2xl leading-relaxed">
                Run this single-file script in your local terminal to continuously extract live DTC Shopify brands across 30 e-commerce niches. Features anti-ban headers, DuckDuckGo dorking, video UGC qualification, and clean CSV export.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => handleDownload('ugc_lead_scraper.py', pythonScript)}
              className="px-4 py-2 text-xs font-bold rounded-xl bg-[#E5A823] hover:bg-[#F5B82E] text-black transition-all flex items-center gap-2 shadow-lg shadow-[#E5A823]/20 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Download .py Script
            </button>
            <button
              onClick={() => handleDownload('requirements.txt', 'requests>=2.31.0\nbeautifulsoup4>=4.12.0\nplaywright>=1.42.0\n')}
              className="px-3 py-2 text-xs font-medium rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              requirements.txt
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('script')}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'script'
                ? 'bg-[#E5A823] text-black shadow-md shadow-[#E5A823]/20'
                : 'text-zinc-400 hover:text-white bg-zinc-900 border border-zinc-800'
            }`}
          >
            <FileCode className="w-4 h-4" />
            ugc_lead_scraper.py
          </button>
          <button
            onClick={() => setActiveTab('setup')}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'setup'
                ? 'bg-[#E5A823] text-black shadow-md shadow-[#E5A823]/20'
                : 'text-zinc-400 hover:text-white bg-zinc-900 border border-zinc-800'
            }`}
          >
            <Terminal className="w-4 h-4" />
            Terminal Setup Guide
          </button>
          <button
            onClick={() => setActiveTab('dorks')}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'dorks'
                ? 'bg-[#E5A823] text-black shadow-md shadow-[#E5A823]/20'
                : 'text-zinc-400 hover:text-white bg-zinc-900 border border-zinc-800'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            Google Dorking Cheat Sheet
          </button>
        </div>

        <button
          onClick={() => handleCopy(activeTab === 'script' ? pythonScript : activeTab === 'setup' ? setupCommands : dorkCheatSheet)}
          className="px-3 py-1.5 text-xs font-medium rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-700 transition-colors flex items-center gap-1.5 cursor-pointer"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          {copied ? 'Copied to Clipboard' : 'Copy Active Code'}
        </button>
      </div>

      {/* Code Container */}
      <div className="bg-[#0b0b0e] border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between px-4 py-2.5 bg-black border-b border-zinc-800 text-xs text-zinc-400 font-mono">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block"></span>
            <span className="w-3 h-3 rounded-full bg-yellow-500/80 inline-block"></span>
            <span className="w-3 h-3 rounded-full bg-green-500/80 inline-block"></span>
            <span className="ml-2 text-zinc-300">
              {activeTab === 'script' ? 'ugc_lead_scraper.py (Production Ready)' : activeTab === 'setup' ? 'Terminal Execution Commands' : 'Dorking_Formulas.txt'}
            </span>
          </div>
          <span className="text-[11px] text-[#E5A823]">AIA Media Engine</span>
        </div>

        <pre className="p-6 text-xs font-mono text-zinc-300 overflow-x-auto leading-relaxed max-h-[600px] selection:bg-[#E5A823]/30">
          <code>{activeTab === 'script' ? pythonScript : activeTab === 'setup' ? setupCommands : dorkCheatSheet}</code>
        </pre>
      </div>
    </div>
  );
};
