import React, { useState } from 'react';
import { LeadRecord } from '../types/scraper';
import { X, Copy, Check, Send, Sparkles } from 'lucide-react';

interface ColdEmailModalProps {
  lead: LeadRecord | null;
  onClose: () => void;
}

export const ColdEmailModal: React.FC<ColdEmailModalProps> = ({ lead, onClose }) => {
  const [templateType, setTemplateType] = useState<'creative-fatigue' | 'review-to-ugc' | 'tiktok-shop'>('creative-fatigue');
  const [copied, setCopied] = useState(false);

  if (!lead) return null;

  const reviewAppMention = lead.reviewAppsDetected !== 'None' 
    ? lead.reviewAppsDetected.split(',')[0].trim() 
    : '5-star';

  const templates = {
    'creative-fatigue': {
      title: 'Meta Ads Creative Fatigue Booster',
      subject: `Quick idea for ${lead.brandName}'s Meta Ads (Creative fatigue fix)`,
      body: `Hey ${lead.brandName} team,

I was auditing recent DTC brands in the ${lead.niche.toLowerCase()} space and came across ${lead.brandName}'s storefront.

Checked your active ads in the Meta Ad Library — love the product positioning, but noticed you're leaning heavily on static imagery / minimal video UGC hooks.

We run an AI UGC ad studio specifically for high-growth e-commerce brands. Instead of paying creators $350-$500 per video, our pipeline produces:
- 15-20 hyper-realistic AI creator video variations tailored to your top SKU
- High-converting hooks tested for 3-second thumbstop rate
- 3x lower creative production cost with 48-hour turnaround

We recently generated 3 custom video hook concepts for ${lead.brandName}. Mind if I send over a quick 60-second Loom preview?

Best,
AIA Creative Lead | AIA Media
contact@aia-media.com`
    },
    'review-to-ugc': {
      title: 'Review-to-Video UGC Transformation',
      subject: `Turning ${lead.brandName}'s ${reviewAppMention} reviews into viral video ads`,
      body: `Hey ${lead.brandName} team,

Noticed on ${lead.websiteUrl.replace(/^https?:\/\//, '')} that you have incredible customer feedback and proof hosted on ${reviewAppMention}.

Most DTC brands leave that social proof locked on their product page — but when transformed into authentic video testimonials on TikTok and Reels, conversion rates jump by 28-40%.

We specialize in AI UGC video pipelines:
1. We take your top verified customer reviews
2. We map them to diverse, photorealistic AI creators (speaking naturally in real-life settings)
3. You get ready-to-run TikTok & Meta Ad creatives without shipping physical sample products

Would love to send you 2 sample video creatives tailored to ${lead.brandName}. Are you free for a quick 5-min look this Thursday?

Cheers,
AIA Creative Lead | AIA Media
contact@aia-media.com`
    },
    'tiktok-shop': {
      title: 'TikTok Shop & Spark Ads Scale',
      subject: `AI UGC pipeline for ${lead.brandName} on TikTok Shop`,
      body: `Hey ${lead.brandName} team,

Saw your TikTok footprint (@${lead.tiktok.includes('@') ? lead.tiktok.split('@')[1] : lead.brandName.toLowerCase()}) and noticed the huge opportunity for scaling TikTok Shop and Spark Ads.

The biggest bottleneck on TikTok is creative volume — algorithms fatigue video hooks every 7-10 days.

Our AI UGC engine generates high-volume, trend-native UGC videos for ${lead.niche.toLowerCase()} brands at a fraction of creator agency rates:
- No creator ghosting
- Infinite A/B testing on hooks, soundbites, and CTAs
- Scaled for TikTok Shop GMV growth

Can I share 3 AI creator concepts built specifically around ${lead.brandName}'s bestseller?

Best,
AIA Creative Lead | AIA Media
contact@aia-media.com`
    }
  };

  const activeTemplate = templates[templateType];

  const handleCopy = () => {
    const fullText = `Subject: ${activeTemplate.subject}\n\n${activeTemplate.body}`;
    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xs">
      <div className="bg-[#0b0b0e] border border-[#E5A823]/30 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl shadow-black">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-[#E5A823]/20 bg-[#070709]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-black border border-[#E5A823]/40 p-1 flex items-center justify-center">
              <img 
                src="/assets/aistudio/AIA-5_b1617e8d.png" 
                alt="AIA Logo" 
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-white tracking-wide uppercase">
                  AIA Cold Outreach Pitch Generator
                </h2>
                <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-[#E5A823]/20 text-[#E5A823] border border-[#E5A823]/40">
                  AI UGC Agency
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                Targeting: <span className="text-zinc-200 font-medium">{lead.brandName}</span> • <span className="text-[#E5A823]">{lead.primaryEmail}</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-900 border border-transparent hover:border-zinc-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Template Selector Tabs */}
        <div className="p-3 bg-black/90 border-b border-zinc-900 flex flex-wrap gap-2">
          {(['creative-fatigue', 'review-to-ugc', 'tiktok-shop'] as const).map(key => (
            <button
              key={key}
              onClick={() => setTemplateType(key)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                templateType === key
                  ? 'bg-[#E5A823] text-black shadow-md shadow-[#E5A823]/20'
                  : 'bg-zinc-900/90 text-zinc-400 hover:text-white border border-zinc-800 hover:border-zinc-700'
              }`}
            >
              {templates[key].title}
            </button>
          ))}
        </div>

        {/* Email Editor View */}
        <div className="p-5 space-y-4 max-h-[60vh] overflow-y-auto bg-[#0b0b0e]">
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wider text-[#E5A823] block mb-1">
              Recipient Direct Email:
            </label>
            <div className="font-mono text-xs text-[#E5A823] bg-black border border-[#E5A823]/30 px-3 py-2 rounded-lg flex items-center justify-between">
              <span>{lead.primaryEmail}</span>
              <span className="text-[10px] uppercase px-1.5 py-0.5 rounded bg-zinc-900 text-zinc-400 border border-zinc-800">Verified Public Lead</span>
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
              Subject Line:
            </label>
            <div className="font-mono text-xs text-zinc-100 bg-black border border-zinc-800 px-3 py-2 rounded-lg">
              {activeTemplate.subject}
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
              Personalized AI Pitch:
            </label>
            <textarea
              readOnly
              value={activeTemplate.body}
              rows={10}
              className="w-full font-mono text-xs text-zinc-300 bg-black border border-zinc-800 p-3 rounded-lg leading-relaxed resize-none focus:outline-none focus:border-[#E5A823]/50"
            />
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-[#070709] border-t border-[#E5A823]/20 flex items-center justify-between">
          <span className="text-xs text-zinc-400">
            Targeting brand: <strong className="text-white">{lead.brandName}</strong> ({lead.niche})
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied Pitch!' : 'Copy to Clipboard'}
            </button>

            <a
              href={`mailto:${lead.primaryEmail}?subject=${encodeURIComponent(activeTemplate.subject)}&body=${encodeURIComponent(activeTemplate.body)}`}
              className="px-4 py-1.5 text-xs font-bold rounded-lg bg-[#E5A823] hover:bg-[#F5B82E] text-black transition-all flex items-center gap-1.5 cursor-pointer shadow-md shadow-[#E5A823]/20"
            >
              <Send className="w-3.5 h-3.5" />
              Open in Mail Client
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
