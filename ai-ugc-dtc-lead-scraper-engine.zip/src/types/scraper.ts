export interface LeadRecord {
  id: string;
  brandName: string;
  websiteUrl: string;
  niche: string;
  primaryEmail: string;
  allEmails: string[];
  instagram: string;
  tiktok: string;
  facebook: string;
  metaAdLibraryUrl: string;
  ugcOpportunityScore: number; // 0 - 100
  qualificationTier: 'HOT' | 'WARM' | 'STANDARD';
  hasVideoEmbeds: boolean;
  hasTikTokPixel: boolean;
  hasMetaPixel: boolean;
  reviewAppsDetected: string;
  hasUgcMentions: boolean;
  suggestedPitchAngle: string;
  scrapedAt: string;
}

export type NicheCategory = 
  | 'skincare'
  | 'supplements'
  | 'fitness'
  | 'gadgets'
  | 'apparel'
  | 'pet'
  | 'home';

export interface DorkQueryItem {
  id: string;
  title: string;
  dork: string;
  platform: 'Shopify' | 'WooCommerce' | 'TikTok Shop' | 'Universal DTC';
  purpose: string;
}
